# Fnugg Ski Resort Block

## Installation

1 `yarn install`

2 `yarn build`
